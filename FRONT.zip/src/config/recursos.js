
const Resources = {

	
	
}

export default Resources;