import './style.css';

const banner = () => {
	return( 
		<div className="compBanner">
			<h2>SOY UN BANNER</h2>
		</div>
	)
};

export default banner;