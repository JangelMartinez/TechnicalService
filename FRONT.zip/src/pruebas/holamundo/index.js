import './style.css';

const holamundo = () => {
	return( 
		<div className="compHolamundo">
			<h2>SOY HOLA MUNDO</h2>
		</div>
	)
};

export default holamundo;