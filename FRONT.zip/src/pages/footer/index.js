import React from 'react'
import {NavLink, Link} from 'react-router-dom'


const Footer = () => {
	return (
		<div className="container-fluid">
		<nav className="navbar navbar-expand-lg navbar-dark bg-primary">
				<div className="container">
					<div className="row align-items-center">
						<div className="col-2">
							<h3 className="navbar-brand">
								<NavLink to="/app/home/home" className="nav-link link-light ">Technical-service</NavLink>
							</h3>
						</div>
						<div className="col-6">
							<div className="collapse navbar-collapse">
									<ul className="navbar-nav ms-5">
										<li className="nav-item">
											<NavLink to="/app/company/list" className="nav-link">Empresas</NavLink>
										</li>
										<li className="nav-item">
											<NavLink to="/app/product/list" className="nav-link">Productos</NavLink>
										</li>
										<li className="nav-item">
											<NavLink to="/app/contact/list" className="nav-link">Contactos</NavLink>
										</li>
										<li className="nav-item">
											<NavLink to="/app/action/list" className="nav-link">Acciones</NavLink>
										</li>
										<li className="nav-item">
											<NavLink to="/app/cases/list" className="nav-link">Incidencias</NavLink>
										</li>
									</ul>
							</div>
						</div>
						<div className="col-2" >
									<ul className="navbar-nav">
										<li className="nav-item">
											<img src="" height="80px" width="80px" alt=""/>	
										</li>				
										<li className="nav-item ms-2 mt-2">
												<div className="small fw-bold" >Nombre</div>
												<div className="small fw-bold" >Teléfono</div>
												<div className="small fw-bold" >Mail</div>
												
										</li>
									</ul>
						</div>
						<div className="col-2">
							<div className="small text-end">
								<Link to="/app/profile/profile" className="small btn btn-info btn-sm">
								Perfil</Link>
							</div>
						</div>
					</div>	
				</div>
			</nav>
			</div>
	)
}

export default Footer;
